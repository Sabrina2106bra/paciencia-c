#include <stdbool.h>
#include "core.h"

bool comparaNaipe(const wchar_t * n1, const wchar_t * n2)
{
    return (n1 == paus && n2 == copas) || (n1 == paus && n2 == ouros) ||
            (n1 == espadas && n2 == copas) || (n1 == espadas && n2 == ouros) ||
            (n1 == copas && n2 == paus) || (n1 == copas && n2 == espadas) ||
            (n1 == ouros && n2 == paus) || (n1 == ouros && n2 == espadas);
}

bool comparaNaipeCrescente(const wchar_t * n1, const wchar_t * n2)
{
    return (n1 == paus && n2 == paus) || (n1 == ouros && n2 == ouros) ||
            (n1 == copas && n2 == copas) || (n1 == espadas && n2 == espadas);
}

void verificarNaipe(Lista *l, Lista *l1, Jogador *j)
{
    No *c1 = l->fim;
    No *c2 = l1->fim;

    if(comparaNaipe(c1->carta.naipe, c2->carta.naipe))
        trocarElementos(l, l1, j);
    else
        mvprintw(row - 4, 3, "%s", "Movimento inválido.");
}

int inserirNosCopia(No **inicio, Carta c)
{
    No *tmp = malloc(sizeof(No));
    int sucesso = tmp != NULL;

    if (sucesso) { 
        tmp->carta = c;
        tmp->prox = NULL;
        while (*inicio)
            inicio = &(*inicio)->prox;
        *inicio = tmp;
    }
    return sucesso;
}

No *copiarNosLista(No *origem)
{
    No *destino = NULL;

    while(origem != NULL) {
        inserirNosCopia(&destino, origem->carta);
        origem = origem->prox;
    }

    return destino;
}

void moverMaisCartasTeste(Lista * origem, Lista * destino, char * valor)
{
    No * m = copiarNosLista(cartasVisiveis(origem));

    if (destino->inicio == NULL && strcmp(m->carta.valor, "K") == 0) { 
        while (m != NULL) {
            inserirElementosNo(destino, m);
            m = m->prox;
        }
    } else { 
        while (m != NULL) {
            if (m->carta.valor == valor)
                inserirElementosNo(destino, m);
            m = m->prox;
        }
    }
    apagarCartasVisiveisTeste(origem, valor);
}

void moverMaisCartas(Lista * origem, Lista * destino)
{
    No * m = copiarNosLista(cartasVisiveis(origem));

    if (destino->inicio == NULL && strcmp(m->carta.valor, "K") == 0) { 
        while (m != NULL) {
            inserirElementosNo(destino, m);
            m = m->prox;
        }
    } else { 
        while (m != NULL) {
            inserirElementosNo(destino, m);
            m = m->prox;
        }
    }
    apagarCartasVisiveis(origem);
}

void verificarNaipeMoverMaisCartas(Lista *origem, Lista *destino)
{
    No *c1 = cartasVisiveis(origem);
    No *c2 = destino->fim;

    if(comparaNaipe(c1->carta.naipe, c2->carta.naipe))
        moverMaisCartas(origem, destino);
    else  
        mvprintw(row - 4, 3, "%s", "Movimento inválido.");
}

void verificarNaipeComprar(Lista *l, Lista *l1, Jogador *j)
{
    No *c1 = l->fim;
    No *c2 = l1->inicio;
    
    if (comparaNaipe(c1->carta.naipe, c2->carta.naipe)) 
        trocarElementosDeck(l, l1, j);
    else 
        mvprintw(row - 4, 3, "%s", "Movimento inválido.");
}

void verificarNaipeManilha(Pilha *p, Lista *l1, Jogador *j)
{
    No *topo = p->topo;
    No *c1 = l1->fim;
    No *inicio = l1->inicio;

    if (p->topo == NULL) { 
        inserirManilha(p, l1, j);
    } else if (comparaNaipeCrescente(topo->carta.naipe, c1->carta.naipe)) { 
        inserirManilha(p, l1, j);
        return;
    } else if (comparaNaipeCrescente(topo->carta.naipe, inicio->carta.naipe)){
        inserirManilhaDireto(p, l1, j);
        return;
    } else { 
        mvprintw(row - 4, 3, "%s", "Movimento inválido.");
    }
}

void vNaipeManilha(Pilha *p, Lista *l1, Jogador *j)
{
    No *topo = p->topo;
    No *inicio = l1->inicio;

    if (p->topo == NULL) { 
        inserirManilha(p, l1, j);
    } else if (comparaNaipeCrescente(topo->carta.naipe, inicio->carta.naipe)) { 
        inserirManilhaDireto(p, l1, j);
    } else { 
        mvprintw(row - 4, 3, "%s", "Movimento inválido.");
    }
}

// Responsável por ordernar as cartas de forma decrescente nas listas encadeadas.
void decrescente(Lista *destino, Lista *origem, Jogador *j)
{
    if (origem->fim == NULL) {
        mvprintw(row - 4, 4, "%s", "Coluna vazia!");
        return;
    } else if (destino->inicio == NULL && origem->fim->carta.valor == valores[12]) { 
        trocarElementos(destino, origem, j);
        return;
    } else {
        for (int i = 0; i < 13; i++) {
            if (destino->fim->carta.valor == valores[i] && origem->fim->carta.valor == valores[i - 1]) {
                verificarNaipe(destino, origem, j);
                break;
            }
        }
    }
}

void decrescenteComprar(Lista *destino, Lista *origem, Jogador *j)
{
    if (origem->inicio == NULL) {
        mvprintw(row - 4, 4, "%s", "Descarte vazio!");
        return;
    } else { 
        if (destino->inicio == NULL && origem->inicio->carta.valor == valores[12]) { 
            trocarElementosDeck(destino, origem, j);
        }

        for (int i = 0; i < 13; i++) { 
            if (destino->fim->carta.valor == valores[i] && origem->inicio->carta.valor == valores[i - 1]) {
                verificarNaipeComprar(destino, origem, j);
                break;
            }
        }
    }
}

// Verificar ordem decrescente para mover mais cartas
void decrescenteMoverMaisCartas(Lista *origem, Lista *destino)
{
    if (origem == NULL) { 
        mvprintw(row - 4, 4, "%s", "Coluna vazia!");
        return;
    } else { 
        No *n = cartasVisiveis(origem);
        if (destino->inicio == NULL && n->carta.valor == valores[12]) { 
            moverMaisCartas(origem, destino);
        }
        for (int i = 0; i < 13; i++) { 
            if (destino->fim->carta.valor == valores[i] && n->carta.valor == valores[i - 1]) {
                verificarNaipeMoverMaisCartas(origem, destino);
                break;
            }
        }
    }
}

void crescenteManilhaDireto(Pilha *p, Lista *l1, Jogador *j)
{
    if (p->topo == NULL) {
        if (l1->inicio->carta.valor == valores[0]) 
            inserirManilhaDireto(p, l1, j);
        else
            return; 
    } else { 
        for (int i = 0; i < 13; i++) { 
            if (p->topo->carta.valor == valores[i] && l1->inicio->carta.valor == valores[i + 1]) {
                vNaipeManilha(p, l1, j);
                break;
            }
        }
    }
}

void crescenteManilha(Pilha *p, Lista *l1, Jogador *j)
{
    No *atual = l1->fim;

    if (p->topo == NULL) { 
        if (atual->carta.valor == valores[0]) 
            inserirManilha(p, l1, j);
        else
            return;
    } else { 
        for (int i = 0; i < 13; i++) { 
            if (p->topo->carta.valor == valores[i] && atual->carta.valor == valores[i + 1]) {
                verificarNaipeManilha(p, l1, j);
                break;
            }
        }
    }
}
