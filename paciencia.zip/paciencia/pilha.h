#ifndef PILHA_H
#define PILHA_H
#include "lista.h"

typedef struct Pilha
{
    No *topo;
    int numCartas;
} Pilha;

#endif