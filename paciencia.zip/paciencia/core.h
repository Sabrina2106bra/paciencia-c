#ifndef CORE_H
#define CORE_H

#include "pilha.h"
#include "lista.h"
#include "main.h"

bool comparaNaipe(const wchar_t * n1, const wchar_t * n2); // Lógica do jogo
bool comparaNaipeCrescente(const wchar_t * n1, const wchar_t * n2); // Lógica do jogo
void verificarNaipe(Lista *l, Lista *l1, Jogador *j); // Lógica do jogo
int inserirNosCopia(No **inicio, Carta c); // Lógica do jogo
No *copiarNosLista(No *origem); // Lógica do jogo
void moverMaisCartasTeste(Lista * origem, Lista * destino, char * valor); // Lógica do jogo
void moverMaisCartas(Lista * origem, Lista * destino); // Lógica do jogo
void verificarNaipeMoverMaisCartas(Lista *origem, Lista *destino); // Lógica do jogo
void verificarNaipeComprar(Lista *l, Lista *l1, Jogador *j); // Lógica do jogo
void verificarNaipeManilha(Pilha *p, Lista *l1, Jogador *j); // Lógica do jogo
void vNaipeManilha(Pilha *p, Lista *l1, Jogador *j); // Lógica do jogo
void decrescente(Lista *destino, Lista *origem, Jogador *j); // Lógica do jogo
void decrescenteComprar(Lista *destino, Lista *origem, Jogador *j); // Lógica do jogo
void decrescenteMoverMaisCartas(Lista *origem, Lista *destino); // Lógica do jogo
void crescenteManilhaDireto(Pilha *p, Lista *l1, Jogador *j); // Lógica do jogo
void crescenteManilha(Pilha *p, Lista *l1, Jogador *j); // Lógica do jogo
void fimDoJogo(Pilha **p); // Lógica do jogo
void ranking(Jogador * j);// Lógica do jogo

#endif