#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <curses.h>
#include <string.h>
#include <time.h>
#include <locale.h>
#include <stdbool.h>
#include "controles.h"
#include "lista.h"
#include "pilha.h"
#include "jogador.h"
#include "interface.h"

extern const wchar_t *paus;
extern const wchar_t *espadas;
extern const wchar_t *copas;
extern const wchar_t *ouros;
extern char *valores[13];
extern int row, col;

typedef struct Lista_Estatica {
    struct Carta cartas[52];
    int nElementos;
} Lista_Estatica;

// Lista Encadeada
void enfileira(Lista *Fila, Lista_Estatica *estatica, int indice); // Lista Encadeada
No *recuperaInicio(Lista *l); // Lista Encadeada
No *desenfileira(Lista *lista); // Lista Encadeada
void inserirElementos(Lista *l, Lista *f); // Lista Encadeada
No *cartasVisiveis(Lista *l); // Lista Encadeada
void inserirElementosNo(Lista *l, No *n); // Lista Encadeada
void deletarElementos(Lista *l); // Lista Encadeada
void trocarElementos(Lista *l, Lista *l1, Jogador *j); // Lista Encadeada
void apagarCartasVisiveis(Lista *l); // Lista Encadeada
void trocarElementosDeck(Lista *l, Lista *l1, Jogador *j); // Lista Encadeada
void apagarCartasVisiveisTeste(Lista *l, char *valor); // Lista Encadeada
void enfileiraFim(Lista *lista, No *no); // Lista Encadeada

// Pilha 
void inserirManilha(Pilha *p, Lista *l, Jogador *j);  // Pilha
void inserirManilhaDireto(Pilha *p, Lista *l, Jogador *j); // Pilha
void inserirCartasPilha(Pilha *pilha, Lista_Estatica *estatica, int indice); // Pilha
No *peek(Pilha *p, int x); // Pilha

// Main
Lista *iniciarLista();
Pilha *iniciarPilha();
Lista_Estatica *embaralharCartas(Lista_Estatica *lista); 
void inserirCartasEstatica(Lista_Estatica *lista); 
void iniciarJogo(); // Main
int main(); // Main

#endif
