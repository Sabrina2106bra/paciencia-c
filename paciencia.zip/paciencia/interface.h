#ifndef INTERFACE_H
#define INTERFACE_H

#include "cartas.h"
#include "lista.h"
#include "pilha.h"
#include "main.h"

// Interface
void fazerCartas(Carta c, int x, int y);  // Interface - Desenha as Cartas do jogo
void fazerCartasDescarte(Carta c);  //Interface - Desenha as Cartas do descarte
void fazerCartasManilha(Carta c, int x);  //Interface - Desenha as Cartas da manilha
void esconderElementos(Lista *l, int x, int y); // Interface - Desenha as Cartas
void intro(); // Interface
void lerRanking(); // Interface
void gameUI(Pilha **p, Jogador *j);  // Interface
void interfaceCreditos(); // Interface
void menu();


#endif