#ifndef JOGADOR_H
#define JOGADOR_H

typedef struct Jogador {
    char nome[20];
    int pontuacao;
} Jogador;

#endif