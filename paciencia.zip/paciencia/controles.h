#ifndef CONTROLES_H
#define CONTROLES_H

#include "pilha.h"
#include "jogador.h"
#include "core.h"

void opcoesDoJogo(int choicesSize, Lista **arr, Pilha **p, Lista *f, Jogador *j);

#endif